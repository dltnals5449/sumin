package com.petshop.purchase.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SalesQuantity {
	private String date;
	private int quantity;
}
