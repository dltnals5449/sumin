package com.petshop.purchase.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class CartVO {

	private int cart;
	private String mid;
	private int pno;
	private int qty;
	private String result;
	

}
