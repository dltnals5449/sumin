package com.petshop.purchase.dto;

import lombok.Data;

@Data
public class CategoryVO {
	private Integer cno;
	private String cname;
	private Integer dcno;
}
