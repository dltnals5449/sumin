package com.petshop.admin.dto;


import lombok.Data;

@Data
public class ReservationListAllVO {
	private int rno;
	private String mid;
	private String rrdate;
	private String rtime;
	private String rteacher;
	private String sname;
}
