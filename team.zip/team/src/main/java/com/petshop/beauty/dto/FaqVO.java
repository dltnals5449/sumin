package com.petshop.beauty.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FaqVO {
	
	private int faqno;
	private String catego;
	private String faqtitle;
	private String faqcontent;
	
}
