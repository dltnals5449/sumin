package com.petshop.beauty.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ServiceVO {
	
	private int sno;
	private String sname;
	private int spay;

}
