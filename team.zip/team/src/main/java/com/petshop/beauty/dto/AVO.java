package com.petshop.beauty.dto;



import java.sql.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class AVO {
	private int qano;
	private int qno;
	private String acontent;
	private Date adate;

}
